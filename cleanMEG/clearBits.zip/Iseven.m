% function flag=Iseven(n)
%
% Returns 1 if n is even

function flag=Iseven(n)
flag =(abs(n)-floor(abs(n)/2)*2)==0;

