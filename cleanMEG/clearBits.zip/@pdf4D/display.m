function display(obj)

get(obj, 'id')